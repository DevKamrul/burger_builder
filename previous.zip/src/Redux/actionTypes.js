//ingredent add and remove from this redux file

export const ADD_INGREDIENT = "ADD_INGREDIENT";
export const REMOVE_INGREDIENT = "REMOVE_INGREDIENT";
export const UPDATE_PURCHASABLE = "UPDATE_PURCHASABLE";
export const RESET_INGREDIENT = "RESET_INGREDIENT";

export const LOAD_ORDER = "LOAD_ORDER";
export const ORDER_LOAD_FAILD = "ORDER_LOAD_FAILD";

export const AUTH_SUCCESS = "AUTH_SUCCESS";
export const AUTH_FAILED = "AUTH_FAILED";
export const AUTH_LOADING = "AUTH_LOADING";
export const AUTH_LOGOUT = "AUTH_LOGOUT";


