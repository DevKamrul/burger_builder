import React from 'react';
import './spinner.css';

const spinner = () => {
    return (
        <div>
            <div className="loader">Loading...</div>
        </div>
    )
}

export default spinner;
